import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, Building2, Briefcase } from 'lucide-react';
import Dashboard from './components/Dashboard';
import DepartmentView from './components/DepartmentView';
import EmployeeView from './components/EmployeeView';
import ProjectView from './components/ProjectView';
import './index.css';

function App() {
  return (
    <BrowserRouter>
      <div className="app-container">
        <aside className="sidebar">
          <div className="sidebar-logo">
            <h1>⬡ HR Tracker</h1>
            <p>Corporate Resource Manager</p>
          </div>

          <span className="sidebar-section-label">Main Menu</span>

          <NavLink to="/" end className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <LayoutDashboard className="nav-icon" />
            Dashboard
          </NavLink>
          <NavLink to="/departments" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Building2 className="nav-icon" />
            Departments
          </NavLink>
          <NavLink to="/employees" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Users className="nav-icon" />
            Employees
          </NavLink>
          <NavLink to="/projects" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Briefcase className="nav-icon" />
            Projects
          </NavLink>

          <div style={{ marginTop: 'auto', padding: '0.75rem', borderTop: '1px solid var(--glass-border)' }}>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textAlign: 'center' }}>
              MongoDB · Express · React
            </p>
          </div>
        </aside>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/departments" element={<DepartmentView />} />
            <Route path="/employees" element={<EmployeeView />} />
            <Route path="/projects" element={<ProjectView />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;
