import { useState, useEffect } from 'react';
import { Users, Building2, Briefcase, TrendingUp, Clock } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import api from '../api';

export default function Dashboard() {
  const [stats, setStats] = useState({ deps: 0, emps: 0, projs: 0 });
  const [projects, setProjects] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      try {
        const [d, e, p] = await Promise.all([
          api.get('/departments'),
          api.get('/employees'),
          api.get('/projects')
        ]);
        setStats({ deps: d.data.length, emps: e.data.length, projs: p.data.length });
        setProjects(p.data.slice(0, 4));
        setEmployees(e.data.slice(0, 5));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchStats();
  }, []);

  const statusColor = (s) => {
    if (s === 'Active') return 'badge-green';
    if (s === 'Planning') return 'badge-blue';
    if (s === 'On Hold') return 'badge-amber';
    if (s === 'Completed') return 'badge-muted';
    return 'badge-muted';
  };

  if (loading) return (
    <div className="empty-state" style={{ minHeight: '60vh' }}>
      <div style={{ width: 40, height: 40, borderRadius: '50%', border: '3px solid var(--accent)', borderTopColor: 'transparent', animation: 'spin 0.8s linear infinite' }} />
      <p>Loading dashboard…</p>
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div className="page-title">
          <h1>Dashboard</h1>
          <p>Welcome back — here's your corporate overview</p>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue"><Building2 size={24} /></div>
          <div className="stat-info">
            <h3>Departments</h3>
            <p>{stats.deps}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green"><Users size={24} /></div>
          <div className="stat-info">
            <h3>Employees</h3>
            <p>{stats.emps}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon amber"><Briefcase size={24} /></div>
          <div className="stat-info">
            <h3>Projects</h3>
            <p>{stats.projs}</p>
          </div>
        </div>
      </div>

      {/* Bottom Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>

        {/* Recent Projects */}
        <div className="glass-card">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <TrendingUp size={18} style={{ color: 'var(--accent-light)' }} />
              <h2 style={{ fontSize: '1rem', fontWeight: 600, margin: 0 }}>Active Projects</h2>
            </div>
            <NavLink to="/projects" style={{ fontSize: '0.75rem', color: 'var(--accent-light)', textDecoration: 'none' }}>View all →</NavLink>
          </div>
          {projects.length === 0 ? (
            <div className="empty-state" style={{ padding: '2rem' }}>
              <p>No projects yet</p>
            </div>
          ) : projects.map(p => (
            <div key={p._id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem 0', borderBottom: '1px solid var(--glass-border)' }}>
              <div>
                <p style={{ fontWeight: 500, fontSize: '0.875rem' }}>{p.projectName}</p>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: 2 }}>${p.budget?.toLocaleString()} budget</p>
              </div>
              <span className={`badge ${statusColor(p.status)}`}>{p.status}</span>
            </div>
          ))}
        </div>

        {/* Recent Employees */}
        <div className="glass-card">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Clock size={18} style={{ color: 'var(--success)' }} />
              <h2 style={{ fontSize: '1rem', fontWeight: 600, margin: 0 }}>Recent Employees</h2>
            </div>
            <NavLink to="/employees" style={{ fontSize: '0.75rem', color: 'var(--accent-light)', textDecoration: 'none' }}>View all →</NavLink>
          </div>
          {employees.length === 0 ? (
            <div className="empty-state" style={{ padding: '2rem' }}>
              <p>No employees yet</p>
            </div>
          ) : employees.map(e => (
            <div key={e._id} style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.65rem 0', borderBottom: '1px solid var(--glass-border)' }}>
              <div className="entity-avatar" style={{ width: 34, height: 34, fontSize: '0.75rem' }}>
                {e.name?.charAt(0).toUpperCase()}
              </div>
              <div>
                <p style={{ fontWeight: 500, fontSize: '0.875rem' }}>{e.name}</p>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: 2 }}>{e.role} · {e.department?.code}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
