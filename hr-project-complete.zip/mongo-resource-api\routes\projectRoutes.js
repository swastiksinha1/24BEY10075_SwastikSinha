const express = require('express');
const router = express.Router();
const projectController = require('../controllers/projectController');

/**
 * @swagger
 * components:
 *   schemas:
 *     Project:
 *       type: object
 *       required:
 *         - projectName
 *         - budget
 *       properties:
 *         projectName:
 *           type: string
 *         status:
 *           type: string
 *           enum: [Planning, Active, On Hold, Completed]
 *         budget:
 *           type: number
 *         teamMembers:
 *           type: array
 *           items:
 *             type: string
 */

router.get('/', projectController.getAllProjects);
router.get('/:id', projectController.getProjectById);
router.post('/', projectController.createProject);
router.put('/:id', projectController.updateProject);
router.post('/:projectId/assign/:employeeId', projectController.assignEmployee);
router.delete('/:id', projectController.deleteProject);

module.exports = router;
