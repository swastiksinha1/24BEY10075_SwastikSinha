import { useState, useEffect } from 'react';
import { Plus, Trash2, Briefcase, X, DollarSign, Users } from 'lucide-react';
import api from '../api';

function Modal({ title, onClose, children }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-panel" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

const STATUS_OPTIONS = ['Planning', 'Active', 'On Hold', 'Completed'];

const statusClass = (s) => {
  if (s === 'Active') return 'badge-green';
  if (s === 'Planning') return 'badge-blue';
  if (s === 'On Hold') return 'badge-amber';
  if (s === 'Completed') return 'badge-muted';
  return 'badge-muted';
};

export default function ProjectView() {
  const [projects, setProjects] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [assignModal, setAssignModal] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [form, setForm] = useState({ projectName: '', budget: '', status: 'Planning' });

  const fetchData = async () => {
    const [p, e] = await Promise.all([api.get('/projects'), api.get('/employees')]);
    setProjects(p.data);
    setEmployees(e.data);
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post('/projects', { ...form, budget: Number(form.budget) });
    setForm({ projectName: '', budget: '', status: 'Planning' });
    setShowModal(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this project?')) {
      await api.delete(`/projects/${id}`);
      fetchData();
    }
  };

  const handleAssign = async () => {
    if (!selectedEmployee || !assignModal) return;
    await api.post(`/projects/${assignModal}/assign/${selectedEmployee}`);
    setAssignModal(null);
    setSelectedEmployee('');
    fetchData();
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-title">
          <h1>Projects</h1>
          <p>{projects.length} project{projects.length !== 1 ? 's' : ''} being tracked</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> New Project
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="glass-card">
          <div className="empty-state">
            <div className="empty-state-icon"><Briefcase size={28} style={{ color: 'var(--text-muted)' }} /></div>
            <h3>No projects yet</h3>
            <p>Create your first project and assign your team to it.</p>
            <button className="btn btn-primary" onClick={() => setShowModal(true)}><Plus size={16} /> Create Project</button>
          </div>
        </div>
      ) : (
        <div className="entity-grid">
          {projects.map(p => (
            <div key={p._id} className="entity-card">
              <div className="entity-card-header">
                <div className="entity-avatar" style={{ background: 'var(--warning-dim)', color: 'var(--warning)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: '10px' }}>
                  <Briefcase size={18} />
                </div>
                <div className="entity-actions">
                  <button className="btn btn-ghost btn-icon" onClick={() => { setAssignModal(p._id); setSelectedEmployee(employees[0]?._id || ''); }} title="Assign Employee">
                    <Users size={14} />
                  </button>
                  <button className="btn btn-danger btn-icon" onClick={() => handleDelete(p._id)} title="Delete">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <h3>{p.projectName}</h3>
              <p style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', marginTop: '0.15rem' }}>
                <DollarSign size={12} style={{ color: 'var(--success)' }} />
                {p.budget?.toLocaleString()} budget
              </p>
              <div className="entity-meta">
                <span className={`badge ${statusClass(p.status)}`}>{p.status}</span>
                <span className="badge badge-muted">
                  <Users size={10} /> {p.teamMembers?.length || 0} members
                </span>
              </div>
              {p.teamMembers?.length > 0 && (
                <div style={{ marginTop: '0.85rem', borderTop: '1px solid var(--glass-border)', paddingTop: '0.75rem', display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                  {p.teamMembers.map(m => (
                    <div key={m._id} title={m.name} className="entity-avatar" style={{ width: 28, height: 28, fontSize: '0.65rem' }}>
                      {m.name?.charAt(0).toUpperCase()}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Create Modal */}
      {showModal && (
        <Modal title="New Project" onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Project Name</label>
              <input className="form-control" placeholder="e.g. Website Redesign" value={form.projectName}
                onChange={e => setForm({ ...form, projectName: e.target.value })} required />
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label>Budget ($)</label>
                <input className="form-control" type="number" placeholder="50000" value={form.budget}
                  onChange={e => setForm({ ...form, budget: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Status</label>
                <select className="form-control" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  {STATUS_OPTIONS.map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary"><Plus size={16} /> Create Project</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Assign Employee Modal */}
      {assignModal && (
        <Modal title="Assign Employee to Project" onClose={() => setAssignModal(null)}>
          <div className="form-group">
            <label>Select Employee</label>
            <select className="form-control" value={selectedEmployee} onChange={e => setSelectedEmployee(e.target.value)}>
              {employees.map(e => <option key={e._id} value={e._id}>{e.name} — {e.role}</option>)}
            </select>
          </div>
          <div className="form-actions">
            <button className="btn btn-ghost" onClick={() => setAssignModal(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={handleAssign}><Users size={16} /> Assign</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
