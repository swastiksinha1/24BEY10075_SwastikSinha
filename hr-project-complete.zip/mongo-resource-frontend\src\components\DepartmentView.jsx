import { useState, useEffect } from 'react';
import { Plus, Trash2, Pencil, Building2, X } from 'lucide-react';
import api from '../api';

function Modal({ title, onClose, children }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-panel" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export default function DepartmentView() {
  const [departments, setDepartments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: '', code: '' });

  const fetchDepartments = async () => {
    const res = await api.get('/departments');
    setDepartments(res.data);
  };

  useEffect(() => { fetchDepartments(); }, []);

  const openCreate = () => { setEditing(null); setForm({ name: '', code: '' }); setShowModal(true); };
  const openEdit = (d) => { setEditing(d); setForm({ name: d.name, code: d.code }); setShowModal(true); };
  const closeModal = () => setShowModal(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editing) {
      await api.put(`/departments/${editing._id}`, form);
    } else {
      await api.post('/departments', form);
    }
    closeModal();
    fetchDepartments();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this department?')) {
      await api.delete(`/departments/${id}`);
      fetchDepartments();
    }
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-title">
          <h1>Departments</h1>
          <p>{departments.length} department{departments.length !== 1 ? 's' : ''} in your organisation</p>
        </div>
        <button className="btn btn-primary" onClick={openCreate}>
          <Plus size={16} /> New Department
        </button>
      </div>

      {departments.length === 0 ? (
        <div className="glass-card">
          <div className="empty-state">
            <div className="empty-state-icon"><Building2 size={28} style={{ color: 'var(--text-muted)' }} /></div>
            <h3>No departments yet</h3>
            <p>Create your first department to start organising your team.</p>
            <button className="btn btn-primary" onClick={openCreate}><Plus size={16} /> Create Department</button>
          </div>
        </div>
      ) : (
        <div className="entity-grid">
          {departments.map(d => (
            <div key={d._id} className="entity-card">
              <div className="entity-card-header">
                <div className="entity-avatar">
                  {d.name.charAt(0).toUpperCase()}
                </div>
                <div className="entity-actions">
                  <button className="btn btn-ghost btn-icon" onClick={() => openEdit(d)} title="Edit">
                    <Pencil size={14} />
                  </button>
                  <button className="btn btn-danger btn-icon" onClick={() => handleDelete(d._id)} title="Delete">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <h3>{d.name}</h3>
              <p>Department</p>
              <div className="entity-meta">
                <span className="badge badge-blue">{d.code}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <Modal title={editing ? 'Edit Department' : 'New Department'} onClose={closeModal}>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Department Name</label>
              <input className="form-control" placeholder="e.g. Engineering" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="form-group">
              <label>Department Code</label>
              <input className="form-control" placeholder="e.g. ENG01" value={form.code}
                onChange={e => setForm({ ...form, code: e.target.value })} required />
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={closeModal}>Cancel</button>
              <button type="submit" className="btn btn-primary">
                <Plus size={16} /> {editing ? 'Save Changes' : 'Create Department'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
