const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } = require("docx");

const content = {
    title: "HR Resource & Project Tracker",
    subtitle: "Project Report",
    domain: "Domain: Human Resources / Management  |  Database: MongoDB  |  Backend: Node.js Express",
    objective: "To design and implement a backend application that manages HR resources, tracks employee profiles, and assigns projects. The system demonstrates native NoSQL MongoDB architecture implementing One-to-One, One-to-Many, and Many-to-Many data relationships, managed via a Node.js Express REST API with interactive Swagger documentation.",
    tools: [
        { name: "Database:", text: " MongoDB — NoSQL document store for all collections" },
        { name: "DB Client:", text: " MongoDB Compass / Atlas — visual interface for managing and querying data" },
        { name: "Backend:", text: " Node.js — JavaScript runtime environment" },
        { name: "Framework:", text: " Express.js — REST API web framework" },
        { name: "Language:", text: " JavaScript (ES6+) — core backend development language" },
        { name: "API Documentation:", text: " Swagger UI (swagger-ui-express) — auto-generated API documentation at /api-docs" },
        { name: "API Testing:", text: " Postman / Swagger UI — endpoint testing during development" },
        { name: "IDE:", text: " Visual Studio Code — development environment" }
    ],
    collections: [
        { name: "departments:", text: " _id, name, location → One-to-Many with employees" },
        { name: "profiles:", text: " _id, title, salary, joinDate → One-to-One with employee" },
        { name: "projects:", text: " _id, name, description, status → Many-to-Many with employees" },
        { name: "employees:", text: " _id, firstName, lastName, email, department, profile, projects[] → central collection" }
    ],
    api: [
        { name: "POST /api/employees:", text: " Insert a new employee record [Create]" },
        { name: "GET /api/employees:", text: " Retrieve all employees from database [Read]" },
        { name: "PUT /api/employees/{id}:", text: " Update employee details by ID [Update]" },
        { name: "DELETE /api/employees/{id}:", text: " Remove an employee from database [Delete]" },
        { name: "GET /api/departments:", text: " Retrieve all departments [Read]" },
        { name: "POST /api/projects:", text: " Add a new project record [Create]" },
        { name: "POST /api/profiles:", text: " Create an employee profile [Create]" }
    ],
    features: [
        { name: "Resource Management:", text: " Centralized tracking of departments, employee profiles, and active projects" },
        { name: "All CRUD Operations:", text: " Create, Read, Update, Delete implemented across all collections" },
        { name: "Complex Relationships:", text: " One-to-One, One-to-Many, and Many-to-Many mappings in MongoDB using Mongoose references" },
        { name: "Swagger UI:", text: " Interactive API documentation auto-generated, enabling easy endpoint exploration and testing" },
        { name: "Scalable Architecture:", text: " MVC-inspired structure with separate routes, controllers, and database models" }
    ],
    footer: "HR Resource & Project Tracker  |  MongoDB + Node.js Express REST API"
};

function createListParagraphs(items) {
    return items.map(item => new Paragraph({
        children: [
            new TextRun({ text: item.name, bold: true, color: "1155cc" }),
            new TextRun({ text: item.text })
        ],
        bullet: { level: 0 },
        spacing: { after: 100 }
    }));
}

function createReport(name) {
    return new Document({
        styles: {
            default: {
                document: {
                    run: {
                        size: 24, // 12pt
                        font: "Arial"
                    }
                }
            }
        },
        sections: [{
            properties: {},
            children: [
                new Paragraph({
                    children: [new TextRun({ text: content.title, bold: true, size: 48, color: "1155cc" })],
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    children: [new TextRun({ text: content.subtitle, italics: true, size: 28, color: "666666" })],
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 100 }
                }),
                new Paragraph({
                    children: [new TextRun({ text: content.domain, size: 24, color: "1155cc" })],
                    alignment: AlignmentType.CENTER,
                    spacing: { after: 300 }
                }),
                
                new Paragraph({
                    children: [new TextRun({ text: "Objective", bold: true, size: 28, color: "1155cc" })],
                    spacing: { before: 200, after: 100 },
                    border: { bottom: { color: "1155cc", space: 1, value: "single", size: 6 } }
                }),
                new Paragraph({
                    text: content.objective,
                    spacing: { after: 200 }
                }),

                new Paragraph({
                    children: [new TextRun({ text: "Tools & Technologies", bold: true, size: 28, color: "1155cc" })],
                    spacing: { before: 200, after: 100 },
                    border: { bottom: { color: "1155cc", space: 1, value: "single", size: 6 } }
                }),
                ...createListParagraphs(content.tools),
                
                new Paragraph({
                    children: [new TextRun({ text: "MongoDB Collections & Relationships", bold: true, size: 28, color: "1155cc" })],
                    spacing: { before: 200, after: 100 },
                    border: { bottom: { color: "1155cc", space: 1, value: "single", size: 6 } }
                }),
                ...createListParagraphs(content.collections),

                new Paragraph({
                    children: [new TextRun({ text: "REST API Modules", bold: true, size: 28, color: "1155cc" })],
                    spacing: { before: 200, after: 100 },
                    border: { bottom: { color: "1155cc", space: 1, value: "single", size: 6 } }
                }),
                ...createListParagraphs(content.api),

                new Paragraph({
                    children: [new TextRun({ text: "Key Features", bold: true, size: 28, color: "1155cc" })],
                    spacing: { before: 200, after: 100 },
                    border: { bottom: { color: "1155cc", space: 1, value: "single", size: 6 } }
                }),
                ...createListParagraphs(content.features),

                new Paragraph({
                    children: [new TextRun({ text: content.footer, italics: true, size: 20, color: "666666" })],
                    alignment: AlignmentType.CENTER,
                    spacing: { before: 600, after: 100 }
                }),
                new Paragraph({
                    children: [new TextRun({ text: `Submitted by: ${name}`, bold: true, size: 24, color: "1155cc" })],
                    alignment: AlignmentType.CENTER
                })
            ]
        }]
    });
}

Packer.toBuffer(createReport("Swastik Sinha")).then((buffer) => {
    fs.writeFileSync("C:/Users/swast/.gemini/antigravity-ide/scratch/hr-project-tracker/Report_Swastik_Sinha.docx", buffer);
    console.log("Created Report_Swastik_Sinha.docx");
});

Packer.toBuffer(createReport("Chhavi Dubey")).then((buffer) => {
    fs.writeFileSync("C:/Users/swast/.gemini/antigravity-ide/scratch/hr-project-tracker/Report_Chhavi_Dubey.docx", buffer);
    console.log("Created Report_Chhavi_Dubey.docx");
});
