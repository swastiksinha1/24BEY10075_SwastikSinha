const Employee = require('../models/Employee');
const EmployeeProfile = require('../models/EmployeeProfile');

exports.createEmployee = async (req, res) => {
  try {
    const { name, email, role, department, profileData } = req.body;

    const profile = new EmployeeProfile(profileData);
    await profile.save();

    const employee = new Employee({
      name,
      email,
      role,
      department,
      profile: profile._id
    });
    await employee.save();

    res.status(201).json(employee);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find().populate('department').populate('profile');
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getEmployeeById = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id).populate('department').populate('profile');
    if (!employee) return res.status(404).json({ message: 'Employee not found' });
    res.status(200).json(employee);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateEmployee = async (req, res) => {
  try {
    const { name, email, role, department, profileData } = req.body;
    
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    if (name) employee.name = name;
    if (email) employee.email = email;
    if (role) employee.role = role;
    if (department) employee.department = department;
    await employee.save();

    if (profileData) {
      await EmployeeProfile.findByIdAndUpdate(employee.profile, profileData);
    }

    const updatedEmployee = await Employee.findById(req.params.id).populate('department').populate('profile');
    res.status(200).json(updatedEmployee);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

exports.deleteEmployee = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) return res.status(404).json({ message: 'Employee not found' });

    await EmployeeProfile.findByIdAndDelete(employee.profile);
    await Employee.findByIdAndDelete(req.params.id);
    
    res.status(200).json({ message: 'Employee and profile deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
