import { useState, useEffect } from 'react';
import { Plus, Trash2, Users, X, Phone, MapPin } from 'lucide-react';
import api from '../api';

function Modal({ title, onClose, children }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-panel" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

const INITIAL_FORM = { name: '', email: '', role: '', department: '', address: '', phone: '', emergencyContact: '' };

export default function EmployeeView() {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(INITIAL_FORM);

  const fetchData = async () => {
    const [empRes, depRes] = await Promise.all([api.get('/employees'), api.get('/departments')]);
    setEmployees(empRes.data);
    setDepartments(depRes.data);
    if (depRes.data.length > 0) setForm(f => ({ ...f, department: depRes.data[0]._id }));
  };

  useEffect(() => { fetchData(); }, []);

  const openModal = () => {
    setForm({ ...INITIAL_FORM, department: departments[0]?._id || '' });
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await api.post('/employees', {
      name: form.name, email: form.email, role: form.role, department: form.department,
      profileData: { address: form.address, phone: form.phone, emergencyContact: form.emergencyContact }
    });
    setShowModal(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Remove this employee?')) {
      await api.delete(`/employees/${id}`);
      fetchData();
    }
  };

  const roleColor = (role) => {
    if (!role) return 'badge-muted';
    const r = role.toLowerCase();
    if (r.includes('manager') || r.includes('lead')) return 'badge-amber';
    if (r.includes('senior')) return 'badge-blue';
    return 'badge-muted';
  };

  return (
    <div>
      <div className="page-header">
        <div className="page-title">
          <h1>Employees</h1>
          <p>{employees.length} team member{employees.length !== 1 ? 's' : ''} across all departments</p>
        </div>
        <button className="btn btn-primary" onClick={openModal}>
          <Plus size={16} /> Onboard Employee
        </button>
      </div>

      {employees.length === 0 ? (
        <div className="glass-card">
          <div className="empty-state">
            <div className="empty-state-icon"><Users size={28} style={{ color: 'var(--text-muted)' }} /></div>
            <h3>No employees yet</h3>
            <p>Onboard your first employee to build out your team directory.</p>
            <button className="btn btn-primary" onClick={openModal}><Plus size={16} /> Add Employee</button>
          </div>
        </div>
      ) : (
        <div className="entity-grid">
          {employees.map(e => (
            <div key={e._id} className="entity-card">
              <div className="entity-card-header">
                <div className="entity-avatar" style={{ background: 'var(--success-dim)', color: 'var(--success)', border: '1px solid rgba(16,185,129,0.2)' }}>
                  {e.name?.charAt(0).toUpperCase()}
                </div>
                <div className="entity-actions">
                  <button className="btn btn-danger btn-icon" onClick={() => handleDelete(e._id)} title="Remove">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <h3>{e.name}</h3>
              <p>{e.email}</p>
              <div className="entity-meta">
                <span className={`badge ${roleColor(e.role)}`}>{e.role || 'N/A'}</span>
                {e.department && <span className="badge badge-blue">{e.department.code}</span>}
              </div>
              {e.profile && (
                <div style={{ marginTop: '0.85rem', borderTop: '1px solid var(--glass-border)', paddingTop: '0.75rem', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <Phone size={11} /> {e.profile.phone}
                  </p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <MapPin size={11} /> {e.profile.address}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <Modal title="Onboard New Employee" onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group">
                <label>Full Name</label>
                <input className="form-control" placeholder="John Doe" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input className="form-control" type="email" placeholder="john@corp.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
              </div>
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label>Job Role</label>
                <input className="form-control" placeholder="e.g. Senior Developer" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Department</label>
                <select className="form-control" value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} required>
                  {departments.map(d => <option key={d._id} value={d._id}>{d.name}</option>)}
                </select>
              </div>
            </div>
            <div className="divider" />
            <div className="form-group">
              <label>Address</label>
              <input className="form-control" placeholder="123 Main St, City" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} required />
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label>Phone</label>
                <input className="form-control" placeholder="555-1234" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Emergency Contact</label>
                <input className="form-control" placeholder="555-9999" value={form.emergencyContact} onChange={e => setForm({ ...form, emergencyContact: e.target.value })} required />
              </div>
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary"><Plus size={16} /> Onboard Employee</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
