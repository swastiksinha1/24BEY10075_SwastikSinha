const express = require('express');
const router = express.Router();
const departmentController = require('../controllers/departmentController');

/**
 * @swagger
 * components:
 *   schemas:
 *     Department:
 *       type: object
 *       required:
 *         - name
 *         - code
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated id of the department
 *         name:
 *           type: string
 *           description: The name of the department
 *         code:
 *           type: string
 *           description: The department code
 *       example:
 *         name: Computer Science
 *         code: CS101
 */

/**
 * @swagger
 * tags:
 *   name: Departments
 *   description: The departments managing API
 */

/**
 * @swagger
 * /api/departments:
 *   get:
 *     summary: Returns the list of all the departments
 *     tags: [Departments]
 *     responses:
 *       200:
 *         description: The list of the departments
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Department'
 */
router.get('/', departmentController.getAllDepartments);

/**
 * @swagger
 * /api/departments/{id}:
 *   get:
 *     summary: Get the department by id
 *     tags: [Departments]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The department id
 *     responses:
 *       200:
 *         description: The department description by id
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         description: The department was not found
 */
router.get('/:id', departmentController.getDepartmentById);

/**
 * @swagger
 * /api/departments:
 *   post:
 *     summary: Create a new department
 *     tags: [Departments]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Department'
 *     responses:
 *       201:
 *         description: The department was successfully created
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       400:
 *         description: Bad request
 */
router.post('/', departmentController.createDepartment);

/**
 * @swagger
 * /api/departments/{id}:
 *   put:
 *     summary: Update the department by the id
 *     tags: [Departments]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The department id
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Department'
 *     responses:
 *       200:
 *         description: The department was updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Department'
 *       404:
 *         description: The department was not found
 *       400:
 *         description: Bad request
 */
router.put('/:id', departmentController.updateDepartment);

/**
 * @swagger
 * /api/departments/{id}:
 *   delete:
 *     summary: Remove the department by id
 *     tags: [Departments]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The department id
 *     responses:
 *       200:
 *         description: The department was deleted
 *       404:
 *         description: The department was not found
 */
router.delete('/:id', departmentController.deleteDepartment);

module.exports = router;
