import axios from 'axios';

// Use VITE_API_URL env variable in production, fallback to localhost for development
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api'
});

export default api;
