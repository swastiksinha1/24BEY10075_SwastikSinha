const mongoose = require('mongoose');

const EmployeeProfileSchema = new mongoose.Schema({
  address: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
  emergencyContact: {
    type: String,
  }
}, { timestamps: true });

module.exports = mongoose.model('EmployeeProfile', EmployeeProfileSchema);
